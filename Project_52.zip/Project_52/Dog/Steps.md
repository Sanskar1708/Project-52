Step 1) Fold and unfold the paper in half both ways.

step 2) Fold the 4 corners in towards the center.

step 3) Unfold the left corner of paper.

step 4) Fold the paper in half horizontally.

step 5) Open up the top layer of paper along the dotted line.

step 6) Keep opening up the paper and Squash Fold it flat. Look at the next step to see how the final fold should look.

step 7) Fold the top layer of paper up along the dotted line.

step 8) Fold both sides of the head in to make ears along the dotted lines.

step 9) Fold the top layer of paper down along the dotted line.

step 10) Fold the paper inside the model along the dotted line and repeat behind.

step 11) Rotate the model so it’s standing upright.